package com.cls.audio_players

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
