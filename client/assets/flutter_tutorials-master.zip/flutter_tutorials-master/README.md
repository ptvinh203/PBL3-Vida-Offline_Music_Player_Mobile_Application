# Welcome to my Flutter tutorials!

### :page_with_curl: Topics
* [Audio Player](https://github.com/FlorianPruemer/flutter_tutorials/tree/master/audio_players) &rarr; In this tutorial, you learn how to play an audio file in your Flutter app.

:arrow_right: Watch my <a href="https://www.youtube.com/playlist?list=PL0kMjh_O0eNdleGLZtd9lIXMioypkqCiJ" target="_blank">Youtube tutorials</a> for a detailed insight into each covered topic
